USE csv_dataset;
SHOW FULL TABLES;
SELECT * FROM products LIMIT 1000;
SELECT * FROM products;
SELECT name, phone FROM shippers;
SELECT
    AVG(price) AS average_price,
	MAX(price) AS max_price,
    MIN(price) AS min_price
FROM products;
SELECT DISTINCT category_id, price
FROM products
ORDER BY price DESC
LIMIT 10;
SELECT COUNT(*) AS product_count
FROM products
WHERE price BETWEEN 20 AND 100;
SELECT 
    supplier_id,
    COUNT(*) AS total_products,
    AVG(price) AS average_price
FROM products
GROUP BY supplier_id;

    
